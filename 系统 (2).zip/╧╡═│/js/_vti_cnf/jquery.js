vti_encoding:SR|utf8-nl
vti_author:SR|ASUS-PC;ASUS
vti_modifiedby:SR|ASUS-PC;ASUS
vti_timelastmodified:TR|06;2016;14;21;08 -0000
vti_timecreated:TR|06;2016;14;21;08 -0000
vti_cacheddtm:TX|06;2016;14;21;08 -0000
vti_filesize:IR|70843
vti_extenderversion:SR|6.0;2;6551
vti_backlinkinfo:VX|left.html;sj;asp;top.html;yh;asp
